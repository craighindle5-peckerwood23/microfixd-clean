// src/autonomy/model-registry.ts
//
// Closes a real, confirmed gap: four model identifiers were hardcoded
// independently across chat.ts, generate.ts, and voice.ts, with no
// central record of what's pinned or which version produced a given
// output. This is the single source of truth now -- every call site
// imports its model id from here instead of a literal string, and every
// response that used a model reports which registry entry it used, so
// two clones of this system are provably running the same models
// (or a diff shows exactly which ones drifted).

export interface PinnedModel {
  role: string;
  provider: 'google' | 'groq' | 'elevenlabs';
  model: string;
  pinnedAt: string; // when this pin was last changed, not when the file was read
  usedFor: string;
}

// Changing a value here is the one real, auditable place a model gets
// upgraded -- not a grep-and-replace across three files.
export const MODEL_REGISTRY: Record<string, PinnedModel> = {
  'chat-intent-interpreter': {
    role: 'chat-intent-interpreter',
    provider: 'google',
    model: 'gemini-2.5-flash',
    pinnedAt: '2026-09-04',
    usedFor: 'Picks one governed intent name from free-form chat text in chat.ts. Never generates the reply itself.',
  },
  'code-generator': {
    role: 'code-generator',
    provider: 'groq',
    model: 'llama-3.3-70b-versatile',
    pinnedAt: '2026-09-04',
    usedFor: 'Generates the file map returned by /api/autonomy/generate.',
  },
  'voice-primary': {
    role: 'voice-primary',
    provider: 'elevenlabs',
    model: 'eleven_multilingual_v2',
    pinnedAt: '2026-09-04',
    usedFor: 'Primary TTS voice (Nick, British) in voice.ts.',
  },
  'voice-fallback': {
    role: 'voice-fallback',
    provider: 'groq',
    model: 'playai-tts',
    pinnedAt: '2026-09-04',
    usedFor: 'TTS fallback in voice.ts when ElevenLabs is unavailable or ELEVENLABS_API_KEY is unset.',
  },
};

export function getPinnedModel(role: keyof typeof MODEL_REGISTRY): PinnedModel {
  const entry = MODEL_REGISTRY[role];
  if (!entry) throw new Error(`No pinned model registered for role "${role}". Add it to MODEL_REGISTRY before using it.`);
  return entry;
}
