import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { createMcpExpressApp } from '@modelcontextprotocol/sdk/server/express.js';
import * as z from 'zod';

const getServer = () => {
  const server = new McpServer({ name: 'test-mcp-server', version: '1.0.0' }, { capabilities: {} });
  server.registerTool('add_numbers', {
    description: 'Adds two real numbers and returns the sum',
    inputSchema: { a: z.number(), b: z.number() },
  }, async ({ a, b }) => ({ content: [{ type: 'text', text: String(a + b) }] }));
  return server;
};

const app = createMcpExpressApp();
app.post('/mcp', async (req, res) => {
  const server = getServer();
  const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
  await server.connect(transport);
  await transport.handleRequest(req, res, req.body);
  res.on('close', () => { transport.close(); server.close(); });
});

app.listen(3900, () => console.log('test MCP server listening on 3900'));
